import numpy as np
from pytorch_grad_cam import GradCAM, HiResCAM, ScoreCAM, GradCAMPlusPlus, AblationCAM, XGradCAM, EigenCAM, FullGrad
from pytorch_grad_cam.utils.model_targets import ClassifierOutputTarget
from pytorch_grad_cam.utils.image import show_cam_on_image
from pytorch_grad_cam.utils.image import (
    show_cam_on_image, deprocess_image, preprocess_image
)
import os
os.environ['CUDA_VISIBLE_DEVICES'] = '1'
import cv2
from model import *


model = DIR2CI(512,7).cuda()

target_layers = [model.featurizer.layer4[-1]]

img_root = '/data1/lbx/data/PACS'

file_names = []

with open(img_list,'r') as f:
    images_list = f.readlines()
    for row in images_list:
        row = row.strip().split(' ')
        file_names.append(row[0])





cam = GradCAM(model=model, target_layers=target_layers)

targets = None

# You can also pass aug_smooth=True and eigen_smooth=True, to apply smoothing.
for i in range(len(file_names)):
    img_name = file_names[i]
    img_path = os.path.join(img_root,img_name)
    rgb_img=cv2.imread(img_path,1)[:,:,::-1]
    rgb_img = np.float32(rgb_img/255)
    input_tensor = preprocess_image(rgb_img,mean=[0.485, 0.456, 0.406],
                                    std=[0.229, 0.224, 0.225]).cuda()
    grayscale_cam = cam(input_tensor=input_tensor, targets=targets)

# In this example grayscale_cam has only one image in the batch:
    grayscale_cam = grayscale_cam[0, :]
    visualization = show_cam_on_image(rgb_img,grayscale_cam, use_rgb=True)
    cam_image = cv2.cvtColor(visualization,cv2.COLOR_RGB2BGR)

# You can also get the model outputs without having to re-inference
    #model_outputs = cam.outputs
    output_path = os.path.join(output_floder,img_name)
    cv2.imwrite(output_path,cam_image)
    print(i)
print('ok')