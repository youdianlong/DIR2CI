import torch
from torch.autograd import Variable
from model import *
import argparse
from utils.datasets import *
import scipy.io as sp
import os
import numpy as np
from utils.utils import *
os.environ['CUDA_VISIBLE_DEVICES'] = '2'
from PIL import ImageFile
ImageFile.LOAD_TRUNCATED_IMAGES = True

def get_args():
    train_arg_parser = argparse.ArgumentParser(description="parser")
    train_arg_parser.add_argument("--iterations", type=int, default=1000,
                                  help="")
    train_arg_parser.add_argument("--batch_size", type=int, default=32,
                                  help="")
    train_arg_parser.add_argument("--num_classes", type=int, default=7, help="")
    train_arg_parser.add_argument("--num_domains", type=int, default=4,help="")
    train_arg_parser.add_argument("--epochs", type=int, default=100,
                                  help="")
    train_arg_parser.add_argument("--unseen_index", type=int, default=1,
                                  help="")
    train_arg_parser.add_argument("--model_path", type=str, default='checkpoints',
                                  help='')
    train_arg_parser.add_argument("--data_root", type=str, default="/data1/lbx/data/PACS", help='')
    train_arg_parser.add_argument("--eval_interval", type=int, default=50,
                                  help="")
    train_arg_parser.add_argument("--train", type=bool, default=True,
                                  help='')
    args = train_arg_parser.parse_args()


    return args



def train(args):
    iterations = args.iterations

    w_mut=0
    w_con=0.1

    w_mmd = 2
    w_ae = 0.1
    w_cls = 1
    max_acc = 0.0
    max_target_acc = 0.0
    eval_interval = args.eval_interval

    from_domain = 'all'
    alpha = 1.0




    names_train,label_train,source_name_train = load_pacs_train_data(args.unseen_index)

    train_dataset = Fourier_PACS_DGDataset(args, names_train, label_train, img_transform, from_domain, alpha)
    train_dataloader=torch.utils.data.DataLoader(train_dataset,batch_size=args.batch_size,shuffle=True, pin_memory=False, drop_last=True)

    names_val,label_val,source_val = load_pacs_val_data(args.unseen_index)
    val_dataset = DGDataset(args, names_val, label_val, val_transform)
    val_dataloader = torch.utils.data.DataLoader(val_dataset,batch_size=args.batch_size,shuffle=True, pin_memory=False, drop_last=True)

    names_test,label_test,source_test = load_pacs_test_data(args.unseen_index)
    test_dataset = DGDataset(args,names_test,label_test,val_transform)
    test_dataloader = torch.utils.data.DataLoader(test_dataset,batch_size=args.batch_size,shuffle=True,pin_memory=False,drop_last=True)


    model = DIR2CI(512,args.num_classes).cuda()

    contraloss = nn.MSELoss()


    optimizer_model = torch.optim.Adam(model.parameters(), 10e-5)


    encoderLoss = MMD_Loss_func(3)
    taskLoss = nn.CrossEntropyLoss()
    decoderLoss = nn.MSELoss()
    #mulloss
    mutLoss=DJSLoss()


    for it in range(iterations):
        # flag = 0
            # try:
        data_list, labels_list ,domain_list= next(iter(train_dataloader))
        for i in range(len(data_list)):
            data_term =data_list[i]
            label_term = labels_list[i]
            domain_term = domain_list[i]
            data_term, label_term,d_label_term = Variable(data_term,requires_grad=False).cuda(), Variable(label_term,requires_grad=False).cuda(),Variable(domain_term,requires_grad=False).cuda()
            if i ==0:
                data =data_term
                labels = label_term
                d_labels = d_label_term
                type = torch.ones(data_term.size(0))*0
                type = Variable(type,requires_grad =False).cuda()
            else:
                data,labels,d_labels = torch.cat((data,data_term),dim=0),torch.cat((labels,label_term),dim=0),torch.cat((d_labels,d_label_term),dim =0)
                type_term = torch.ones(data_term.size(0))*i
                type_term = Variable(type_term,requires_grad = False).cuda()
                type = torch.cat((type,type_term),dim=0)




        features,e,d,t,mu,logvar=model(data,labels)
        info_loss = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
        index1= torch.where(type==0)
        e_ori = e[index1]
        index2 = torch.where(type==2)
        e_aug = e[index2]
        index3 = torch.where(type==3)
        e_aug_s=e[index3]
        index4 = torch.where(type==1)
        e_ori_s=e[index4]



        t_loss = taskLoss(t,labels)

        contra_loss = contraloss(e_ori,e_aug)+contraloss(e_ori_s,e_aug_s)

        d_loss = decoderLoss(d,features)




        mmd_loss = encoderLoss(e,d_labels)

        total_loss =  w_cls * t_loss + w_ae * d_loss  + w_mmd * mmd_loss+w_con*contra_loss+w_mut*info_loss
        print('iteration{}:t_loss:{}, d_loss:{}, mmd_loss:{},mut_loss:{},contra_loss:{}'.format(it,t_loss.item(),d_loss.item(),mmd_loss.item(),info_loss.item(),contra_loss.item()))

        optimizer_model.zero_grad()
        total_loss.backward()
        optimizer_model.step()



        if (it % eval_interval == 0) and (it != 0):
            acc = evaluate(model, val_dataloader)
            if acc > max_acc:
                max_acc = acc
            target_acc = test(model, test_dataloader)
            if target_acc > max_target_acc:
                torch.save(model.state_dict())
                max_target_acc = target_acc
        print('acc:{},target_acc:{}'.format(max_acc, max_target_acc))

    return

def evaluate(model,source_datasets_val):
    model.eval()
    correct = 0.0
    total = 0.0

    for batch_i, (data,labels,domain) in enumerate(source_datasets_val):
        data, labels = Variable(data, requires_grad=False).cuda(), Variable(labels, requires_grad=False).cuda()
        featurs,e,d,t,_,_= model(data,labels)
        preds = torch.argmax(t,dim=1)
        correct += torch.sum(preds == labels)
        total += preds.size(0)
    acc = correct/total
    print('---------------val_acc:{}-----------------------'.format(acc))
    model.train()
    return acc



if __name__ == '__main__':
    args = get_args()
    train(args)