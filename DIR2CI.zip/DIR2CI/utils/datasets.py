import torch
from torch.utils.data import Dataset

from utils.utils import *

import torch.nn.functional as F

class VLSC_dataset(Dataset):
    def __init__(self, data,labels):
        super(VLSC_dataset,self).__init__()
        self.data = data.copy()
        self.labels = labels.copy()

        # self.cal_mean_std()


    def cal_mean_std(self):
        self.mean = np.mean(self.data, axis = 0)
        self.std = np.std(self.data, axis = 0)
        return


    def __getitem__(self, index):
        sample = self.data[index].copy()
        label = self.labels[index].copy()

        sample = torch.tensor(sample)
        label = torch.tensor(int(label))

        return sample,label

    def __len__(self):
        return self.data.shape[0]



#对比损失
class ContraLoss(torch.nn.Module):
    def __init__(self):
        super(ContraLoss, self).__init__()

    def forward(self, out_1, out_2, batch_size, temperature=0.5):
        # 分母 ：X.X.T，再去掉对角线值，分析结果一行，可以看成它与除了这行外的其他行都进行了点积运算（包括out_1和out_2）,
        # 而每一行为一个batch的一个取值，即一个输入图像的特征表示，
        # 因此，X.X.T，再去掉对角线值表示，每个输入图像的特征与其所有输出特征（包括out_1和out_2）的点积，用点积来衡量相似性
        # 加上exp操作，该操作实际计算了分母
        # [2*B, D]
        out_1 = F.normalize(out_1,dim=-1)
        out_2 = F.normalize(out_2,dim=-1)
        out = torch.cat([out_1, out_2], dim=0)
        # [2*B, 2*B]
        sim_matrix = torch.exp(torch.mm(out, out.t().contiguous()) / temperature)
        mask = (torch.ones_like(sim_matrix) - torch.eye(2 * batch_size, device=sim_matrix.device)).bool()
        # [2*B, 2*B-1]
        sim_matrix = sim_matrix.masked_select(mask).view(2 * batch_size, -1)

        # 分子： *为对应位置相乘，也是点积
        # compute loss
        pos_sim = torch.exp(torch.sum(out_1 * out_2, dim=-1) / temperature)
        # [2*B]
        pos_sim = torch.cat([pos_sim, pos_sim], dim=0)
        return (- torch.log(pos_sim / sim_matrix.sum(dim=-1))).mean()
