import os

img_list = os.listdir(img_path)
f = open('test.txt', 'w')
for img in img_list:
    img = img[:-4] + '\n'
    f.write(img)
f.close()

