#Domain-Invariant	Representation	Learning	with	Causal	Invariance

#### Environment

Python==3.6
Pytorch==1.10.1


#### train

```
python test.py
```
